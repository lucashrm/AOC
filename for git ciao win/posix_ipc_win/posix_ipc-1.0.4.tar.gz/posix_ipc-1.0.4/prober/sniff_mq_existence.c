#include <mqueue.h>

int main(void) { 
    mq_unlink("");
    
    return 0;
}

